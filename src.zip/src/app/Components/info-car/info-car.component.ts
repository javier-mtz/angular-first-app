import { Component } from '@angular/core';

@Component({
  selector: 'app-info-car',
  standalone: true,
  imports: [],
  templateUrl: './info-car.component.html',
  styleUrl: './info-car.component.css'
})
export class InfoCarComponent {

}
